package com.liandianqi.app;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
public class ClickAccessibility extends AccessibilityService {
 static volatile ClickAccessibility active;
 @Override public void onServiceConnected(){active=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){}
 @Override public void onInterrupt(){}
 @Override public void onDestroy(){active=null;super.onDestroy();}
 static boolean tap(int x,int y,int ms){ClickAccessibility s=active;if(s==null)return false;try{Path path=new Path();path.moveTo(x,y);GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(new GestureDescription.StrokeDescription(path,0,Math.max(1,Math.min(ms,60000))));CountDownLatch latch=new CountDownLatch(1);final boolean[] ok={false};s.dispatchGesture(b.build(),new GestureResultCallback(){@Override public void onCompleted(GestureDescription d){ok[0]=true;latch.countDown();}@Override public void onCancelled(GestureDescription d){latch.countDown();}},null);return latch.await(Math.max(5,ms/1000+4),TimeUnit.SECONDS)&&ok[0];}catch(Exception e){return false;}}
}
