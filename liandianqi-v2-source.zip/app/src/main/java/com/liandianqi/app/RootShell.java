package com.liandianqi.app;
import java.io.*;
public class RootShell {
 static String check(){try {Process p=new ProcessBuilder("su","-c","id").redirectErrorStream(true).start();BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));String s=r.readLine();int code=p.waitFor();return code==0 && s!=null && s.contains("uid=0")?"Root 授权成功":"Root 未授权："+s;}catch(Exception e){return "Root 检查失败："+e.getMessage();}}
 static boolean tap(int x,int y,int hold){try {String command=hold<=80?"/system/bin/input tap "+x+" "+y:"/system/bin/input swipe "+x+" "+y+" "+x+" "+y+" "+hold;Process p=new ProcessBuilder("su","-c",command).start();return p.waitFor()==0;}catch(Exception e){return false;}}
}
