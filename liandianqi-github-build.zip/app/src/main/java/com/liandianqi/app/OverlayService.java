package com.liandianqi.app;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class OverlayService extends Service {
 WindowManager wm; LinearLayout controls; WindowManager.LayoutParams controlsParams; final ArrayList<Point> points=new ArrayList<>();final AtomicBoolean running=new AtomicBoolean(false);Thread worker;int index=0;
 class Point {int x,y,hold=100,min=500,max=1000,count=0; TextView view;WindowManager.LayoutParams params;}
 @Override public IBinder onBind(Intent i){return null;}
 WindowManager.LayoutParams params(int w,int h,int x,int y){WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;p.x=x;p.y=y;return p;}
 TextView control(String text,Runnable r){TextView v=new TextView(this);v.setText(text);v.setTextColor(Color.WHITE);v.setBackgroundColor(0xff303f9f);v.setPadding(14,14,14,14);controls.addView(v);v.setOnClickListener(w->r.run());return v;}
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);controls.setBackgroundColor(0xff303f9f);control("＋",this::addPoint);control("开始",this::start);control("停止",this::stop);control("关闭",()->stopSelf());controlsParams=params(-2,-2,20,120);wm.addView(controls,controlsParams);}
 void addPoint(){Point p=new Point();p.x=150+points.size()*60;p.y=400+points.size()*70;p.params=params(110,110,p.x,p.y);p.view=new TextView(this);p.view.setText("点"+(++index)+"\n设置");p.view.setTextSize(15);p.view.setTextColor(Color.WHITE);p.view.setGravity(Gravity.CENTER);p.view.setBackgroundColor(0xcc008577);wm.addView(p.view,p.params);points.add(p);p.view.setOnTouchListener(new View.OnTouchListener(){float downX,downY;int oldX,oldY;boolean moved;public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();oldX=p.params.x;oldY=p.params.y;moved=false;return true;case MotionEvent.ACTION_MOVE:int dx=(int)(e.getRawX()-downX),dy=(int)(e.getRawY()-downY);if(Math.abs(dx)+Math.abs(dy)>12)moved=true;p.params.x=oldX+dx;p.params.y=oldY+dy;wm.updateViewLayout(p.view,p.params);return true;case MotionEvent.ACTION_UP:p.x=p.params.x+55;p.y=p.params.y+55;if(!moved)edit(p);return true;}return true;}});}
 void edit(Point p){LinearLayout form=new LinearLayout(this);form.setOrientation(1);EditText[] inputs=new EditText[4];String[] names={"按住毫秒","最短间隔毫秒","最长间隔毫秒","次数（0=无限）"};int[] values={p.hold,p.min,p.max,p.count};for(int i=0;i<4;i++){EditText t=new EditText(this);t.setSingleLine(true);t.setInputType(2);t.setHint(names[i]);t.setText(""+values[i]);form.addView(t);inputs[i]=t;}AlertDialog dialog=new AlertDialog.Builder(this).setTitle("设置点击点").setView(form).setPositiveButton("保存",(d,w)->{try{int a=Integer.parseInt(inputs[0].getText().toString()),b=Integer.parseInt(inputs[1].getText().toString()),c=Integer.parseInt(inputs[2].getText().toString()),n=Integer.parseInt(inputs[3].getText().toString());if(a<1||b<0||c<b||n<0)throw new Exception();p.hold=a;p.min=b;p.max=c;p.count=n;}catch(Exception e){Toast.makeText(this,"参数不合法",Toast.LENGTH_SHORT).show();}}).setNeutralButton("删除",(d,w)->{wm.removeView(p.view);points.remove(p);}).setNegativeButton("取消",null).create();dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);dialog.show();
 }
 void start(){if(running.get()||points.isEmpty())return;running.set(true);for(Point point:points)point.view.setVisibility(View.GONE);ArrayList<Point> snapshot=new ArrayList<>(points);worker=new Thread(()->{Random random=new Random();try{boolean any=true;int[] done=new int[snapshot.size()];while(running.get()&&any){any=false;for(int i=0;i<snapshot.size()&&running.get();i++){Point p=snapshot.get(i);if(p.count!=0&&done[i]>=p.count)continue;any=true;boolean ok=RootShell.tap(p.x,p.y,p.hold);if(!ok){running.set(false);break;}done[i]++;long delay=p.min+(p.max==p.min?0:random.nextInt(p.max-p.min+1));Thread.sleep(delay);}}}catch(InterruptedException ignored){}finally{running.set(false);new Handler(Looper.getMainLooper()).post(()->{for(Point point:points)point.view.setVisibility(View.VISIBLE);});}},"root-click-loop");worker.start();}
 void stop(){running.set(false);if(worker!=null)worker.interrupt();}
 @Override public void onDestroy(){stop();for(Point p:points)try{wm.removeView(p.view);}catch(Exception ignored){}try{wm.removeView(controls);}catch(Exception ignored){}super.onDestroy();}
}
