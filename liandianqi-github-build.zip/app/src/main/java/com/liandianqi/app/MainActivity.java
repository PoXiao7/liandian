package com.liandianqi.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout layout;
    void line(String s) { TextView t=new TextView(this);t.setText(s);t.setTextSize(17);t.setPadding(12,14,12,14);layout.addView(t); }
    void button(String s,Runnable action) { Button b=new Button(this);b.setText(s);layout.addView(b);b.setOnClickListener(v->action.run()); }
    @Override public void onCreate(Bundle b) {super.onCreate(b);layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(22,28,22,12);setContentView(layout);
        line("连点器 · KernelSU Root 版");line("授权 Root 后，无需无障碍。先允许悬浮窗，再启动控制面板。");
        button("1. 测试 Root 授权",()->new Thread(()->{String s=RootShell.check();runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}).start());
        button("2. 开启悬浮窗权限",()->{Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);});
        button("3. 启动悬浮控制",()->{if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"请先授权悬浮窗",Toast.LENGTH_LONG).show();return;}startService(new Intent(this,OverlayService.class));});
        button("停止并关闭悬浮窗",()->stopService(new Intent(this,OverlayService.class)));
        line("说明：悬浮点可拖动定位。点击“设置”修改按住时长、随机间隔和执行次数。无限次数输入 0。");
    }
}
